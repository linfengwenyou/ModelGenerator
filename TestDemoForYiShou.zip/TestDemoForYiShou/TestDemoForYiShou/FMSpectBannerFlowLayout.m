//
//  FMSpectBannerFlowLayout.m
//  YiShou
//
//  Created by dahl.chen on 2018/3/16.
//  Copyright © 2018年 FuMi. All rights reserved.
//

#import "FMSpectBannerFlowLayout.h"
@interface FMSpectBannerFlowLayout ()

@property(nonatomic, assign) NSInteger itemsCount;

@end
@implementation FMSpectBannerFlowLayout
-(void)prepareLayout {
    [super prepareLayout];
    
//    _itemsCount = [self.collectionView numberOfItemsInSection:0];
    
//    if(_internalItemSpacing == 0)
//        _internalItemSpacing = 5;
//    
//    if(_sectionEdgeInsets.top == 0 && _sectionEdgeInsets.bottom == 0 && _sectionEdgeInsets.left == 0 && _sectionEdgeInsets.right == 0)
//        _sectionEdgeInsets = UIEdgeInsetsMake(0, ([UIScreen mainScreen].bounds.size.width - self.itemSize.width) / 2, 0, ([UIScreen mainScreen].bounds.size.width - self.itemSize.width) / 2);
}

//-(void)scrollToItemAtIndex:(NSInteger)itemIndex {
//    _currentItemIndex = itemIndex;
//    
//    [self.collectionView setContentOffset:CGPointMake(_currentItemIndex * (_internalItemSpacing + self.itemSize.width), 0) animated:YES];
//    
//    if([self.delegate respondsToSelector:@selector(scrolledToTheCurrentItemAtIndex:)])
//        [self.delegate scrolledToTheCurrentItemAtIndex:itemIndex];
//    
//    return ;
//}

//-(UICollectionViewLayoutAttributes *)layoutAttributesForItemAtIndexPath:(NSIndexPath *)indexPath {
//    UICollectionViewLayoutAttributes* attr = [UICollectionViewLayoutAttributes layoutAttributesForCellWithIndexPath:indexPath];
//
//    attr.size = self.itemSize;
//    attr.frame = CGRectMake((int)indexPath.row * (self.itemSize.width + _internalItemSpacing) + _sectionEdgeInsets.left, (self.collectionView.bounds.size.height - self.itemSize.height) / 2 + _sectionEdgeInsets.top, attr.size.width, attr.size.height);
//
//    return attr;
//}

//-(NSArray<UICollectionViewLayoutAttributes *> *)layoutAttributesForElementsInRect:(CGRect)rect {
//    NSMutableArray* attributes = [NSMutableArray array];
//    
//    CGRect visiableRect = CGRectMake(self.collectionView.contentOffset.x, 0, self.collectionView.bounds.size.width, self.collectionView.bounds.size.height);
//    CGFloat centerX = self.collectionView.contentOffset.x + [UIScreen mainScreen].bounds.size.width / 2;
//    
//    for (NSInteger i=0 ; i < _itemsCount; i++) {
//        NSIndexPath* indexPath = [NSIndexPath indexPathForItem:i inSection:0];
//        UICollectionViewLayoutAttributes* attr = [self layoutAttributesForItemAtIndexPath:indexPath];
//        [attributes addObject:attr];
//        
//        if(CGRectIntersectsRect(attr.frame, visiableRect) == false)
//            continue ;
//        CGFloat xOffset = fabs(attr.center.x - centerX);
//        
//        CGFloat scale = 1 - (xOffset * (1 - _scale)) / (([UIScreen mainScreen].bounds.size.width + self.itemSize.width) / 2 - self.internalItemSpacing);
//        attr.transform = CGAffineTransformMakeScale(scale, scale);
//    }
//    
//    return attributes;
//}

//-(BOOL)shouldInvalidateLayoutForBoundsChange:(CGRect)newBounds {
//    return YES;
//}

-(CGPoint)targetContentOffsetForProposedContentOffset:(CGPoint)proposedContentOffset withScrollingVelocity:(CGPoint)velocity {
    
    NSInteger itemIndex = (NSInteger)(self.collectionView.contentOffset.x / (self.itemSize.width + _internalItemSpacing));
    CGFloat xOffset = itemIndex * (_internalItemSpacing + self.itemSize.width);
    CGFloat xOffset_1 = (itemIndex + 1) * (_internalItemSpacing + self.itemSize.width);
    
    if(fabs(proposedContentOffset.x - xOffset) > fabs(xOffset_1 - proposedContentOffset.x)) {
        _currentItemIndex = itemIndex + 1;
        if([self.delegate respondsToSelector:@selector(scrolledToTheCurrentItemAtIndex:)])
            [self.delegate scrolledToTheCurrentItemAtIndex:_currentItemIndex];
        return CGPointMake(xOffset_1-21, 0);
    }
    
    _currentItemIndex = itemIndex;
    
    if([self.delegate respondsToSelector:@selector(scrolledToTheCurrentItemAtIndex:)])
        [self.delegate scrolledToTheCurrentItemAtIndex:_currentItemIndex];
    
    return CGPointMake(xOffset-21, 0);
}

@end
