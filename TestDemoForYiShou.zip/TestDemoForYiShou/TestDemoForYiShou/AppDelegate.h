//
//  AppDelegate.h
//  TestDemoForYiShou
//
//  Created by fumi on 2018/8/7.
//  Copyright © 2018年 fumi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

