//
//  FMSpectBannerFlowLayout.h
//  YiShou
//
//  Created by dahl.chen on 2018/3/16.
//  Copyright © 2018年 FuMi. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol FMSpectBannerFlowLayoutDelegate <NSObject>

@optional
-(void)scrolledToTheCurrentItemAtIndex:(NSInteger)itemIndex;

@end

@interface FMSpectBannerFlowLayout : UICollectionViewFlowLayout
@property(nonatomic, assign) CGFloat internalItemSpacing;
@property(nonatomic, assign) UIEdgeInsets sectionEdgeInsets;
@property(nonatomic, assign) CGFloat scale;
@property(nonatomic, assign) NSInteger currentItemIndex;
@property(nonatomic, assign) NSInteger allIndex;
@property(nonatomic, assign) id<FMSpectBannerFlowLayoutDelegate> delegate;

-(void)scrollToItemAtIndex:(NSInteger)itemIndex;
@end
