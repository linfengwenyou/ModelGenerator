//
//  ViewController.m
//  TestDemoForYiShou
//
//  Created by fumi on 2018/8/7.
//  Copyright © 2018年 fumi. All rights reserved.
//

#import "ViewController.h"
#import "FMCustomScrollView.h"

@interface ViewController ()
/** RGB Color */
#define RGBA(r, g, b, a) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    CGRect frame = CGRectMake(20, 100, self.view.bounds.size.width - 40, 100);
    FMCustomScrollView *scrollView = [FMCustomScrollView customScrollViewWithFrame:frame placeholder:[UIImage imageNamed:@"common_notification"] disableTimer:NO];
    
    scrollView.cellRegisterAction = ^(UICollectionView *collectionView) {
        [collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"CellClass"];
    };
    
    scrollView.cellConfigure = ^UICollectionViewCell *(UICollectionView *collectionView, NSIndexPath *indexPath) {
        UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"CellClass" forIndexPath:indexPath];
        UIColor *color = [UIColor redColor];
        if (indexPath.row == 1) {
            color = [UIColor blueColor];
        } else if (indexPath.row == 2) {
            color = [UIColor greenColor];
        }
        
        cell.backgroundColor = color;
        return cell;
    };
    
    
    scrollView.sectionInset = UIEdgeInsetsMake(0, 5, 0, 5);
    scrollView.itemSize = CGSizeMake(180, 100);
    
    scrollView.imageURLs = @[@"common_notification",@"common_notification",@"common_notification"];
    
    [scrollView finishConfigureView];
    
    [self.view addSubview:scrollView];
    
}


@end
