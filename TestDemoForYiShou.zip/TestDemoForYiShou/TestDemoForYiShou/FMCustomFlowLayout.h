//
//  FMCustomFlowLayout.h
//  TestDemoForYiShou
//
//  Created by fumi on 2018/8/7.
//  Copyright © 2018年 fumi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FMCustomFlowLayout : UICollectionViewFlowLayout
/** 滚动放大，默认为NO */
@property (nonatomic, assign)BOOL scrollEnlarge;

@end
