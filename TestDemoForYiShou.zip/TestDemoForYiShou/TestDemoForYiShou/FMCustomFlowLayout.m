//
//  FMCustomFlowLayout.m
//  TestDemoForYiShou
//
//  Created by fumi on 2018/8/7.
//  Copyright © 2018年 fumi. All rights reserved.
//

#import "FMCustomFlowLayout.h"

@implementation FMCustomFlowLayout

- (void)prepareLayout
{
      [super prepareLayout];
    // 配置
    
}

- (NSArray<UICollectionViewLayoutAttributes *> *)layoutAttributesForElementsInRect:(CGRect)rect
{
    NSArray *attrs = [self deepCopyWithArray:[super layoutAttributesForElementsInRect:rect]];
    
    if (self.scrollEnlarge) {
        CGFloat contentOffsetX = self.collectionView.contentOffset.x;
        CGFloat collectionViewCenterX = self.collectionView.frame.size.width * 0.5;
        for (UICollectionViewLayoutAttributes *attr in attrs) {
            CGFloat scale = 1 - fabs(attr.center.x - contentOffsetX - collectionViewCenterX) /self.collectionView.bounds.size.width*0.2;
            attr.transform = CGAffineTransformMakeScale(scale, scale);
        }
    }

    return attrs;
}


- (BOOL)shouldInvalidateLayoutForBoundsChange:(CGRect)newBounds
{
    return YES;
}

- (CGPoint)targetContentOffsetForProposedContentOffset:(CGPoint)proposedContentOffset withScrollingVelocity:(CGPoint)velocity
{
    if (!self.scrollEnlarge) {
        return proposedContentOffset;
    }
    CGRect rect = CGRectMake(proposedContentOffset.x, 0, self.collectionView.bounds.size.width,self.collectionView.bounds.size.height);
    
    NSArray *attrs = [super layoutAttributesForElementsInRect:rect];
   
    CGFloat contentOffsetX = self.collectionView.contentOffset.x;
    CGFloat collectionViewCenterX = self.collectionView.frame.size.width * 0.5;
    CGFloat minDistance = MAXFLOAT;
    
    for (UICollectionViewLayoutAttributes *attr in attrs) {
        CGFloat distance = attr.center.x - contentOffsetX - collectionViewCenterX;
        if (fabs(distance) < fabs(minDistance)) {
            minDistance = distance;
        }
    }
    proposedContentOffset.x += minDistance;
    return proposedContentOffset;
}

- (NSArray *)deepCopyWithArray:(NSArray *)arr {
    NSMutableArray *arrM = [NSMutableArray array];
    for (UICollectionViewLayoutAttributes *attr in arr) {
        [arrM addObject:[attr copy]];
    }
    return arrM;
}



@end
