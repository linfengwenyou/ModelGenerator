//
//  FMCustomScrollView.h
//  TestDemoForYiShou
//
//  Created by fumi on 2018/8/7.
//  Copyright © 2018年 fumi. All rights reserved.
//
/**
可以自己配置collectionViewCell
 */
#import <UIKit/UIKit.h>

/** 点击 */
typedef void(^FMCustomScollViewClickItemAction)(NSInteger currentIndex);
/** 注册cell */
typedef void(^FMCellRegisterAction)(UICollectionView *collectionView);
/** 配置cell */
typedef UICollectionViewCell *(^FMCellConfigureAction)(UICollectionView *collectionView, NSIndexPath *indexPath);

@class FMCustomScrollView;

@protocol FMCustomScrollViewDelegate <NSObject>
@optional
- (void)cycleRollView:(FMCustomScrollView *)cycleScrollView didSelectItemAtIndex:(NSInteger)index;

@end

@interface FMCustomScrollView : UIView

#pragma mark - initlizer
/** cell注册 */
@property (nonatomic, copy) FMCellRegisterAction cellRegisterAction;
/** cell 配置 */
@property (nonatomic, copy) FMCellConfigureAction cellConfigure;
/** cell 尺寸 内偏移*/
@property (nonatomic, assign) CGSize itemSize;  // 默认为容器尺寸
@property (nonatomic, assign) UIEdgeInsets sectionInset;
/** 配置imageUrl之前必须配置cell */
@property (nonatomic, copy) NSArray *imageURLs;
@property (nonatomic, copy) NSArray *imageNames;
@property (nonatomic, assign) NSTimeInterval timeInterval;
@property (nonatomic, weak) id<FMCustomScrollViewDelegate>delegate;
@property (nonatomic, copy) FMCustomScollViewClickItemAction cycleRollViewClickItemBlock;

+ (instancetype)customScrollViewWithFrame:(CGRect)frame delegate:(id<FMCustomScrollViewDelegate>)delegate placeholder:(UIImage *)image disableTimer:(BOOL)disableTimer;
+ (instancetype)customScrollViewWithFrame:(CGRect)frame placeholder:(UIImage *)image disableTimer:(BOOL)disableTimer;
+ (instancetype)customScrollViewWithFrame:(CGRect)frame placeholder:(UIImage *)image;
- (void)updataUI;

/** 配置结束，开始展示view */
- (void)finishConfigureView;


@end
